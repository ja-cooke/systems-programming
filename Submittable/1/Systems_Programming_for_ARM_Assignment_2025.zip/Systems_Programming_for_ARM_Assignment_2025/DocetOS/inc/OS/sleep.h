#ifndef SLEEP_H
#define SLEEP_H

#include <stdint.h>

#define OS_INTERNAL

void OS_sleep(uint32_t sleepTime);

#endif /* SLEEP_H */