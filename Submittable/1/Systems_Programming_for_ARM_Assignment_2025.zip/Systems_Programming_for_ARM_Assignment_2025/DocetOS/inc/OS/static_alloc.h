#ifndef STATIC_ALLOC_H
#define STATIC_ALLOC_H
#include <stddef.h>

void * static_alloc(size_t bytes);

#endif /* STATIC_ALLOC_H */
